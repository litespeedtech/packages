<?php

/*
 * This file is a dummy template file.
 *
 * It is meant to be used to skip comment processing on the main request
 * when using esi comments.
 */

