<?php
if ( ! defined( 'WPINC' ) ) die ;

?>

1) speed
2) page score
3) Usage summary of CDN bandwidth as another one.
4) Usage of CCSS
5) Usage of image optm
6) Usage of Placeholder online generator
7) Usage of LQIP placeholder generator
8) Crawler status