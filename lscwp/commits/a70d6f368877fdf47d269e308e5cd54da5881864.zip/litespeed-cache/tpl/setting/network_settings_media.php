<?php
namespace LiteSpeed ;
defined( 'WPINC' ) || exit ;
?>

<h3 class="litespeed-title"><?php echo __( 'Network Media Settings', 'litespeed-cache' ) ; ?></h3>

<table class="wp-list-table striped litespeed-table"><tbody>

	<?php require LSCWP_DIR . 'tpl/setting/settings_inc.media_webp.php' ; ?>

</tbody></table>
