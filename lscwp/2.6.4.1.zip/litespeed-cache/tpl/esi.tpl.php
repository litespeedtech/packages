<?php

if ( ! defined('ABSPATH') ) {
    die() ;
}

LiteSpeed_Cache_ESI::load_esi_block() ;


